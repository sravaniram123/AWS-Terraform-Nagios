https://aws.amazon.com/cloudformation/getting-started/

https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ec2-instance.html

ex: https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/sample-templates-applications-eu-west-1.html



https://docs.aws.amazon.com/opsworks/latest/userguide/using-s3-bucket.html

https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/template-anatomy.html
