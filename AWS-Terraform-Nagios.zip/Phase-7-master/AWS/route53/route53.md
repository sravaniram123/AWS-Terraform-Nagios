1. Create a domain. (pending requiests, registered domains)

2. Create Hosted zone. and add Name Servers. (Registered domains --> Domain Name --> Add or edit name servers)

3. Create a Record Set for your website.

4. Access the website with domain name.

https://docs.aws.amazon.com/AmazonS3/latest/dev/website-hosting-custom-domain-walkthrough.html#root-domain-walkthrough-s3-tasks

https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/RoutingToS3Bucket.html

https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/SOA-NSrecords.html

https://www.inmotionhosting.com/support/domain-names/dns-nameserver-changes/what-is-a-name-server

https://support.dnsimple.com/articles/soa-record/

https://www.freenom.com/

FYI:
	https://www.cloudns.net/blog/10-most-used-nslookup-commands/

	nslookup google.com

	nslookup -type=soa google.com

	nslookup -type=mx google.com

	nslookup -type=any google.com

	nslookup -type=ns google.com

	nslookup -type=ns svnreddydevops.com
	nslookup -type=soa svnreddydevops.com
	nslookup -type=any svnreddydevops.com




