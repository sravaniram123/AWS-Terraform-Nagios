* https://docs.aws.amazon.com/general/latest/gr/aws_service_limits.html
