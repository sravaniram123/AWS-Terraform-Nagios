Refer: 
https://aws.amazon.com/elasticbeanstalk/
https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/AWSHowTo.RDS.html#rds-external-defaultvpc

See an example with web application & DB: https://github.com/venkatasykam/DevOpsWebApp/blob/jdbc-eb/README.md
