
##### Abbruvations & terminology

* VPC - Virtual Private Cloud

* IP - Internet Protocol

* CIDR - Classless Internet Domain Routing

* IPv4 - Internet Protocol version 4

* IGW - Internet Gateway

* ACLs - Access Control Lists

* DNS - Domain Name Services

* DHCP - Dynamic Host Configuration Protocol

* VPN - Virtual Private Network

* NAT - Network Address Translation

* EC2 - Elastic Compute Cloud

* Subnet

* Public IP, Private IP

* Route Table

* Security Groups

* NAT Gateways, NAT Instance

* Elastic IPs

* Region, Availability Zones

* Network ACLs

* Inbound and outbound traffic
